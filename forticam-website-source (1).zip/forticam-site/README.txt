FORTICAM website source
=======================

This is a static, responsive website project prepared with the supplied FORTICAM images and promotional video.

Preview locally:
1. Extract this ZIP.
2. Open index.html in a modern browser.

Deploy to Netlify:
1. Sign in to Netlify.
2. Open the site dashboard for forticamin.netlify.app.
3. Use Deploys > deploy manually (or drag the extracted project folder into the Netlify deploy area).
4. Ensure index.html is at the project root and the assets folder is alongside it.

The current site domain is controlled by the Netlify account. This project ZIP does not itself grant access to that account or publish changes.
